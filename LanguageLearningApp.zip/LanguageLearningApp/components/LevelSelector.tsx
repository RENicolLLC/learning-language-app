import React from 'react'

interface LevelSelectorProps {
  level: string;
  setLevel: (level: string) => void;
}

const LevelSelector: React.FC<LevelSelectorProps> = ({ level, setLevel }) => {
  const levels = [
    { value: 'grade1-3', label: 'Grades 1-3: Foundations of English' },
    { value: 'grade4-6', label: 'Grades 4-6: Developing Narratives and Opinions' },
    { value: 'grade7-9', label: 'Grades 7-9: Complex Sentences and Critical Thinking' },
    { value: 'grade10-12', label: 'Grades 10-12: Advanced Writing and Discussions' },
  ]

  return (
    <div className="mb-4">
      <label htmlFor="level" className="block text-sm font-medium text-gray-700">
        Select Grade Level
      </label>
      <select
        id="level"
        value={level}
        onChange={(e) => setLevel(e.target.value)}
        className="mt-1 block w-full pl-3 pr-10 py-2 text-base border-gray-300 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm rounded-md"
      >
        {levels.map((l) => (
          <option key={l.value} value={l.value}>
            {l.label}
          </option>
        ))}
      </select>
    </div>
  )
}

export default LevelSelector

