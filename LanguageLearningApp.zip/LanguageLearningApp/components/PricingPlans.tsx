import React from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"

const plans = [
  { name: 'Free', price: 0, limit: 10 },
  { name: 'Intermediate', price: 20, limit: 50 },
  { name: 'Unlimited', price: 40, limit: Infinity },
];

export function PricingPlans() {
  return (
    <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mt-8">
      {plans.map((plan) => (
        <Card key={plan.name}>
          <CardHeader>
            <CardTitle>{plan.name}</CardTitle>
            <CardDescription>
              ${plan.price}/month
            </CardDescription>
          </CardHeader>
          <CardContent>
            <ul className="list-disc list-inside mb-4">
              <li>{plan.limit === Infinity ? 'Unlimited' : plan.limit} messages per day</li>
              {plan.name !== 'Free' && <li>Priority support</li>}
              {plan.name === 'Unlimited' && <li>Advanced features</li>}
            </ul>
            <Button className="w-full">{plan.name === 'Free' ? 'Get Started' : 'Subscribe'}</Button>
          </CardContent>
        </Card>
      ))}
    </div>
  );
}

