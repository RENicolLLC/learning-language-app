'use client'

import { useState } from 'react';
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"

export function PhoneVerification() {
  const [phoneNumber, setPhoneNumber] = useState('');
  const [verificationCode, setVerificationCode] = useState('');
  const [isVerificationSent, setIsVerificationSent] = useState(false);
  const [isVerified, setIsVerified] = useState(false);

  const handleSendVerification = async () => {
    try {
      const response = await fetch('/api/verify', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ phoneNumber }),
      });

      const data = await response.json();

      if (data.success) {
        setIsVerificationSent(true);
        alert('Verification code sent!');
      } else {
        alert('Failed to send verification code. Please try again.');
      }
    } catch (error) {
      console.error('Error sending verification:', error);
      alert('An error occurred. Please try again.');
    }
  };

  const handleVerifyCode = async () => {
    // Implement code verification logic here
    // This would typically involve another API call to Twilio to check the code
    setIsVerified(true);
    alert('Phone number verified successfully!');
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle>Phone Verification</CardTitle>
      </CardHeader>
      <CardContent>
        {!isVerified ? (
          <>
            <Input
              type="tel"
              placeholder="Enter phone number"
              value={phoneNumber}
              onChange={(e) => setPhoneNumber(e.target.value)}
              className="mb-4"
            />
            <Button onClick={handleSendVerification} disabled={isVerificationSent} className="mb-4">
              Send Verification Code
            </Button>
            {isVerificationSent && (
              <>
                <Input
                  type="text"
                  placeholder="Enter verification code"
                  value={verificationCode}
                  onChange={(e) => setVerificationCode(e.target.value)}
                  className="mb-4"
                />
                <Button onClick={handleVerifyCode}>Verify Code</Button>
              </>
            )}
          </>
        ) : (
          <p>Phone number verified!</p>
        )}
      </CardContent>
    </Card>
  );
}

