import React, { useState, useEffect } from 'react'
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Mic, MicOff, Loader2 } from 'lucide-react'

interface CustomInputProps {
  onSubmit: (input: string) => void;
  nativeLanguage: string;
  isLoading: boolean;
}

const CustomInput: React.FC<CustomInputProps> = ({ onSubmit, nativeLanguage, isLoading }) => {
  const [input, setInput] = useState('')
  const [isListening, setIsListening] = useState(false)
  const [recognition, setRecognition] = useState<SpeechRecognition | null>(null)

  useEffect(() => {
    if ('webkitSpeechRecognition' in window) {
      const recognition = new window.webkitSpeechRecognition()
      recognition.continuous = false
      recognition.interimResults = false
      recognition.lang = getLangCode(nativeLanguage)

      recognition.onresult = (event) => {
        const transcript = event.results[0][0].transcript
        setInput(transcript)
        setIsListening(false)
      }

      recognition.onerror = (event) => {
        console.error('Speech recognition error', event.error)
        setIsListening(false)
      }

      setRecognition(recognition)
    }
  }, [nativeLanguage])

  const getLangCode = (language: string) => {
    const langCodes: { [key: string]: string } = {
      english: 'en-US',
      vietnamese: 'vi-VN',
      chinese: 'zh-CN',
      japanese: 'ja-JP',
      korean: 'ko-KR',
      thai: 'th-TH'
    }
    return langCodes[language] || 'en-US'
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    onSubmit(input)
    setInput('')
  }

  const toggleListening = () => {
    if (recognition) {
      if (isListening) {
        recognition.stop()
      } else {
        recognition.start()
      }
      setIsListening(!isListening)
    }
  }

  return (
    <Card className="w-full mt-6">
      <CardHeader>
        <CardTitle>Practice Area</CardTitle>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleSubmit} className="flex flex-col space-y-4">
          <div className="flex space-x-2">
            <Input
              type="text"
              value={input}
              onChange={(e) => setInput(e.target.value)}
              placeholder={`Enter a phrase in ${nativeLanguage}`}
              className="flex-grow"
            />
            {recognition && (
              <Button type="button" onClick={toggleListening} variant="outline">
                {isListening ? <MicOff className="h-4 w-4" /> : <Mic className="h-4 w-4" />}
              </Button>
            )}
          </div>
          <Button type="submit" disabled={isLoading}>
            {isLoading ? <Loader2 className="h-4 w-4 animate-spin mr-2" /> : null}
            Get Translation and Activity
          </Button>
        </form>
      </CardContent>
    </Card>
  )
}

export default CustomInput

