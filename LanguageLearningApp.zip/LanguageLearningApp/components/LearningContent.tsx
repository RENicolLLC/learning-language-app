import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"

interface LearningContentProps {
  country: string;
  level: string | number;
  content: {
    topics: string;
    example: string;
    activities: string;
  };
  onBack: () => void;
}

export function LearningContent({ country, level, content, onBack }: LearningContentProps) {
  const [nativeText, englishText] = content.example.split('=').map(text => text.trim());

  return (
    <Card className="w-full mt-6">
      <CardHeader>
        <CardTitle>Learning Content for {country} - Level {level}</CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <div>
          <h3 className="font-bold">Topics:</h3>
          <p>{content.topics}</p>
        </div>
        <div>
          <h3 className="font-bold">Example:</h3>
          <div className="grid grid-cols-2 gap-4 p-4 bg-gray-100 rounded-md">
            <div>
              <h4 className="font-semibold">Native Language:</h4>
              <p>{nativeText}</p>
            </div>
            <div>
              <h4 className="font-semibold">English:</h4>
              <p>{englishText}</p>
            </div>
          </div>
        </div>
        <div>
          <h3 className="font-bold">Activities:</h3>
          <p>{content.activities}</p>
        </div>
        <Button onClick={onBack}>Back to Learning Plan</Button>
      </CardContent>
    </Card>
  );
}

