import React, { useState, useEffect } from 'react'
import { Button } from "@/components/ui/button"
import { VolumeIcon as VolumeUp } from 'lucide-react'

interface ContentAreaProps {
  level: string;
  contentType: string;
  nativeLanguage: string;
  customContent?: {
    native: string;
    english: string;
    activity: string;
  } | null;
}

const ContentArea: React.FC<ContentAreaProps> = ({ level, contentType, nativeLanguage, customContent }) => {
  const [content, setContent] = useState({ english: '', native: '', activity: '' })

  useEffect(() => {
    if (customContent) {
      setContent(customContent)
    } else {
      // Here you would typically fetch content based on level, contentType, and nativeLanguage
      // For now, we'll just set some placeholder content
      setContent({
        english: 'This is a sample English sentence.',
        native: 'This is a placeholder for the native language translation.',
        activity: 'Try to translate the English sentence to your native language.',
      })
    }
  }, [level, contentType, nativeLanguage, customContent])

  const speakEnglish = () => {
    const utterance = new SpeechSynthesisUtterance(content.english)
    utterance.lang = 'en-US'
    window.speechSynthesis.speak(utterance)
  }

  return (
    <div className="bg-white shadow overflow-hidden sm:rounded-lg mt-6">
      <div className="px-4 py-5 sm:px-6">
        <h3 className="text-lg leading-6 font-medium text-gray-900">
          {contentType === 'custom' ? 'Language Assistant Result' : `${contentType.charAt(0).toUpperCase() + contentType.slice(1)} - ${level}`}
        </h3>
      </div>
      <div className="border-t border-gray-200">
        <dl>
          <div className="bg-gray-50 px-4 py-5 sm:grid sm:grid-cols-3 sm:gap-4 sm:px-6">
            <div>
              <dt className="text-sm font-medium text-gray-500">English</dt>
              <dd className="mt-1 text-sm text-gray-900 flex items-center">
                {content.english}
                <Button onClick={speakEnglish} variant="ghost" size="sm" className="ml-2">
                  <VolumeUp className="h-4 w-4" />
                </Button>
              </dd>
            </div>
            <div>
              <dt className="text-sm font-medium text-gray-500">{nativeLanguage.charAt(0).toUpperCase() + nativeLanguage.slice(1)}</dt>
              <dd className="mt-1 text-sm text-gray-900">{content.native}</dd>
            </div>
            <div>
              <dt className="text-sm font-medium text-gray-500">Activity</dt>
              <dd className="mt-1 text-sm text-gray-900">{content.activity}</dd>
            </div>
          </div>
        </dl>
      </div>
    </div>
  )
}

export default ContentArea

