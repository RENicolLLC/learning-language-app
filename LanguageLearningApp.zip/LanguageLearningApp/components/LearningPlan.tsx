import React, { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { LearningContent } from './LearningContent'

const countries = [
  { code: 'vn', name: 'Vietnam' },
  { code: 'cn', name: 'China' },
  { code: 'jp', name: 'Japan' },
  { code: 'kr', name: 'South Korea' },
  { code: 'th', name: 'Thailand' },
  { code: 'id', name: 'Indonesia' },
  { code: 'my', name: 'Malaysia' },
  { code: 'ph', name: 'Philippines' },
];

const educationLevels = [
  { name: "Elementary School", grades: [1, 2, 3, 4, 5, 6] },
  { name: "Middle School", grades: [7, 8, 9] },
  { name: "High School", grades: [10, 11, 12] },
  { name: "College", levels: ["Freshman", "Sophomore", "Junior", "Senior"] },
  { name: "Graduate", levels: ["Master's", "Doctorate"] },
];

const contentByCountry = {
  vn: {
    1: {
      topics: "Basic greetings and introductions",
      example: "Hello, my name is... = Xin chào, tên tôi là...",
      activities: "Role-playing introductions, singing alphabet songs",
    },
    2: {
      topics: "Daily routines and basic questions",
      example: "Do you like apples? = Bạn có thích táo không?",
      activities: "Forming simple sentences, answering questions, and talking about daily activities.",
    },
    3: {
      topics: "Describing people and places using adjectives",
      example: "My dog is small and cute. = Con chó của tôi nhỏ và dễ thương.",
      activities: "Describing themselves, their friends, and their surroundings.",
    },
    4: {
      topics: "Telling stories and past events",
      example: "Yesterday, I went to the park. = Hôm qua, tôi đã đi đến công viên.",
      activities: "Writing short paragraphs about weekends and favorite activities.",
    },
    5: {
      topics: "Writing opinions and explaining reasons",
      example: "I like pizza because it is delicious. = Tôi thích pizza vì nó rất ngon.",
      activities: "Opinion-based writing and classroom discussions about likes/dislikes.",
    },
    6: {
      topics: "Writing narratives and using descriptive language",
      example: "The water was blue, and the sand was soft. = Nước biển rất xanh và cát rất mềm.",
      activities: "Writing about personal memories or trips.",
    },
    7: {
      topics: "Explaining steps and giving instructions",
      example: "First, take two slices of bread. = Đầu tiên, lấy hai lát bánh mì.",
      activities: "Writing instructions (e.g., how to make a sandwich) and practicing imperatives.",
    },
    8: {
      topics: "Summarizing stories and describing events",
      example: "The story is about a boy who learns to be brave. = Câu chuyện kể về một cậu bé học cách dũng cảm.",
      activities: "Summarizing books or movies and writing about daily events.",
    },
    9: {
      topics: "Writing essays and expressing opinions",
      example: "I want to be a doctor because I like helping people. = Tôi muốn trở thành bác sĩ vì tôi thích giúp đỡ mọi người.",
      activities: "Writing short essays on future goals or ideal schools.",
    },
    10: {
      topics: "Debating and forming arguments",
      example: "I think technology is good because it helps us learn. = Tôi nghĩ công nghệ tốt vì nó giúp chúng ta học hỏi.",
      activities: "Discussing pros and cons of topics like technology and recycling.",
    },
    11: {
      topics: "Analyzing literature and identifying themes",
      example: "The story shows that friendship is important in hard times. = Câu chuyện cho thấy tình bạn quan trọng trong lúc khó khăn.",
      activities: "Writing about themes and characters in stories or poems.",
    },
    12: {
      topics: "Writing research papers and reflections",
      example: "Climate change causes rising sea levels. = Biến đổi khí hậu gây ra mực nước biển dâng cao.",
      activities: "Advanced essays on global issues, reflections on school years, and critical analysis.",
    },
    "Freshman": {
      topics: "Academic writing and critical thinking",
      example: "The author argues that... = Tác giả lập luận rằng...",
      activities: "Writing academic essays, analyzing scholarly articles",
    },
    "Sophomore": {
      topics: "Research methods and data analysis",
      example: "The data suggests a correlation between... = Dữ liệu cho thấy mối tương quan giữa...",
      activities: "Conducting small research projects, writing research reports",
    },
    "Junior": {
      topics: "Advanced composition and rhetoric",
      example: "This essay will examine the implications of... = Bài luận này sẽ xem xét các hệ quả của...",
      activities: "Writing persuasive essays, giving presentations",
    },
    "Senior": {
      topics: "Thesis writing and professional communication",
      example: "In conclusion, this study demonstrates that... = Để kết luận, nghiên cứu này chứng minh rằng...",
      activities: "Writing a thesis, preparing for job interviews in English",
    },
    "Master's": {
      topics: "Advanced academic writing and research methodologies",
      example: "The findings suggest a correlation between... = Các kết quả cho thấy mối tương quan giữa...",
      activities: "Conducting literature reviews, writing research proposals",
    },
    "Doctorate": {
      topics: "Scholarly publishing and academic presentations",
      example: "This research contributes to the field by... = Nghiên cứu này đóng góp vào lĩnh vực bằng cách...",
      activities: "Writing journal articles, presenting at academic conferences",
    },
  },
  cn: {
    1: {
      topics: "Basic greetings and numbers",
      example: "Hello, how are you? = 你好，你好吗？(Nǐ hǎo, nǐ hǎo ma?)",
      activities: "Counting games, simple dialogues",
    },
    // ... (similar structure for other levels)
    "Doctorate": {
      topics: "Scholarly publishing and academic presentations",
      example: "This research contributes to the field by... = 这项研究通过...对该领域做出了贡献 (Zhè xiàng yánjiū tōngguò... duì gāi lǐngyù zuò chūle gòngxiàn)",
      activities: "Writing journal articles, presenting at academic conferences",
    },
  },
  // ... (similar structures for jp, kr, th, id, my, ph)
};

export function LearningPlan() {
  const [selectedCountry, setSelectedCountry] = useState('vn');
  const [selectedLevel, setSelectedLevel] = useState<string | number | null>(null);

  const getContent = (country: string, level: string | number) => {
    return contentByCountry[country][level] || {
      topics: "Content not available",
      example: "Example not available",
      activities: "Activities not available",
    };
  };

  if (selectedLevel) {
    return (
      <LearningContent
        country={countries.find(c => c.code === selectedCountry)?.name || selectedCountry}
        level={selectedLevel}
        content={getContent(selectedCountry, selectedLevel)}
        onBack={() => setSelectedLevel(null)}
      />
    );
  }

  return (
    <div className="space-y-6">
      <h2 className="text-2xl font-bold">Asian Language Learning Plan</h2>
      <div className="flex space-x-4">
        <Select onValueChange={(value) => setSelectedCountry(value)}>
          <SelectTrigger className="w-[180px]">
            <SelectValue placeholder="Select a country" />
          </SelectTrigger>
          <SelectContent>
            {countries.map((country) => (
              <SelectItem key={country.code} value={country.code}>
                {country.name}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>
      {educationLevels.map((level, index) => (
        <Card key={index}>
          <CardHeader>
            <CardTitle>{level.name}</CardTitle>
            <CardDescription>English learning content for {level.name}</CardDescription>
          </CardHeader>
          <CardContent>
            <Accordion type="single" collapsible>
              {(level.grades || level.levels).map((grade) => (
                <AccordionItem key={grade} value={`grade-${grade}`}>
                  <AccordionTrigger>{typeof grade === 'number' ? `Grade ${grade}` : grade}</AccordionTrigger>
                  <AccordionContent>
                    <div className="space-y-2">
                      <p><strong>Topics:</strong> {getContent(selectedCountry, grade).topics}</p>
                      <div className="grid grid-cols-2 gap-4 p-4 bg-gray-100 rounded-md">
                        <div>
                          <h4 className="font-semibold">Native Language:</h4>
                          <p>{getContent(selectedCountry, grade).example.split('=')[1].trim()}</p>
                        </div>
                        <div>
                          <h4 className="font-semibold">English:</h4>
                          <p>{getContent(selectedCountry, grade).example.split('=')[0].trim()}</p>
                        </div>
                      </div>
                      <p><strong>Activities:</strong> {getContent(selectedCountry, grade).activities}</p>
                      <Button onClick={() => setSelectedLevel(grade)}>Start Learning</Button>
                    </div>
                  </AccordionContent>
                </AccordionItem>
              ))}
            </Accordion>
          </CardContent>
        </Card>
      ))}
    </div>
  );
}

