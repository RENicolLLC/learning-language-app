import React, { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { LearningContent } from './LearningContent'
import { useToast } from "@/components/ui/use-toast"

const countries = [
  { code: 'vn', name: 'Vietnam' },
  { code: 'cn', name: 'China' },
  { code: 'jp', name: 'Japan' },
  { code: 'kr', name: 'South Korea' },
  { code: 'th', name: 'Thailand' },
  { code: 'id', name: 'Indonesia' },
  { code: 'my', name: 'Malaysia' },
  { code: 'ph', name: 'Philippines' },
];

const educationLevels = [
  { name: "Elementary School", grades: [1, 2, 3, 4, 5, 6] },
  { name: "Middle School", grades: [7, 8, 9] },
  { name: "High School", grades: [10, 11, 12] },
  { name: "College", levels: ["Freshman", "Sophomore", "Junior", "Senior"] },
  { name: "Graduate", levels: ["Master's", "Doctorate"] },
];

const contentByCountry = {
  vn: {
    1: {
      topics: "Basic greetings and introductions",
      example: "Hello, my name is... = Xin chào, tên tôi là...",
      activities: "Role-playing introductions, singing alphabet songs",
    },
    2: {
      topics: "Daily routines and basic questions",
      example: "Do you like apples? = Bạn có thích táo không?",
      activities: "Forming simple sentences, answering questions, and talking about daily activities.",
    },
    // ... (add content for other levels)
  },
  // ... (add content for other countries)
};

export function LearningPlan() {
  const [selectedCountry, setSelectedCountry] = useState('vn');
  const [selectedLevel, setSelectedLevel] = useState<string | number | null>(null);
  const [wordCount, setWordCount] = useState(0);
  const { toast } = useToast();

  const getContent = (country: string, level: string | number) => {
    return contentByCountry[country][level] || {
      topics: "Content not available",
      example: "Example not available",
      activities: "Activities not available",
    };
  };

  const generateNewWords = async (grade: string | number) => {
    setWordCount(prevCount => prevCount + 1);
    toast({
      title: "Generating new words",
      description: `New words for grade ${grade} are being generated...`,
    });
    
    await new Promise(resolve => setTimeout(resolve, 1000));

    toast({
      title: "New words generated",
      description: `New words for grade ${grade} are ready!`,
    });
  };

  if (selectedLevel) {
    return (
      <LearningContent
        country={countries.find(c => c.code === selectedCountry)?.name || selectedCountry}
        level={selectedLevel}
        content={getContent(selectedCountry, selectedLevel)}
        onBack={() => setSelectedLevel(null)}
        onGenerateNewWords={() => generateNewWords(selectedLevel)}
      />
    );
  }

  return (
    <div className="space-y-6">
      <h2 className="text-2xl font-bold">Asian Language Learning Plan</h2>
      <div className="flex space-x-4">
        <Select onValueChange={(value) => setSelectedCountry(value)}>
          <SelectTrigger className="w-[180px]">
            <SelectValue placeholder="Select a country" />
          </SelectTrigger>
          <SelectContent>
            {countries.map((country) => (
              <SelectItem key={country.code} value={country.code}>
                {country.name}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>
      {educationLevels.map((level, index) => (
        <Card key={index}>
          <CardHeader>
            <CardTitle>{level.name}</CardTitle>
            <CardDescription>English learning content for {level.name}</CardDescription>
          </CardHeader>
          <CardContent>
            <Accordion type="single" collapsible>
              {(level.grades || level.levels).map((grade) => (
                <AccordionItem key={grade} value={`grade-${grade}`}>
                  <AccordionTrigger>{typeof grade === 'number' ? `Grade ${grade}` : grade}</AccordionTrigger>
                  <AccordionContent>
                    <div className="space-y-2">
                      <p><strong>Topics:</strong> {getContent(selectedCountry, grade).topics}</p>
                      <div className="grid grid-cols-2 gap-4 p-4 bg-gray-100 rounded-md">
                        <div>
                          <h4 className="font-semibold">Native Language:</h4>
                          <p>{getContent(selectedCountry, grade).example.split('=')[1].trim()}</p>
                        </div>
                        <div>
                          <h4 className="font-semibold">English:</h4>
                          <p>{getContent(selectedCountry, grade).example.split('=')[0].trim()}</p>
                        </div>
                      </div>
                      <p><strong>Activities:</strong> {getContent(selectedCountry, grade).activities}</p>
                      <div className="flex space-x-2">
                        <Button onClick={() => setSelectedLevel(grade)}>Start Learning</Button>
                        <Button onClick={() => generateNewWords(grade)} variant="outline">Generate New Words</Button>
                      </div>
                    </div>
                  </AccordionContent>
                </AccordionItem>
              ))}
            </Accordion>
          </CardContent>
        </Card>
      ))}
    </div>
  );
}

