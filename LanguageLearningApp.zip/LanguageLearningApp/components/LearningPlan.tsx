import React, { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion"

const gradeRanges = [
  { name: "1st to 3rd Grades", description: "Foundations of English", grades: [1, 2, 3] },
  { name: "4th to 6th Grades", description: "Developing Narratives and Opinions", grades: [4, 5, 6] },
  { name: "7th to 9th Grades", description: "Complex Sentences and Critical Thinking", grades: [7, 8, 9] },
  { name: "10th to 12th Grades", description: "Advanced Writing and Discussions", grades: [10, 11, 12] },
];

const gradeContent = {
  1: {
    topics: "Everyday objects, greetings, simple actions",
    example: "I see a dog = Tôi thấy một con chó.",
    activities: "Tracing letters, copying short sentences, and recognizing objects.",
  },
  2: {
    topics: "Daily routines and basic questions",
    example: "Do you like apples? = Bạn có thích táo không?",
    activities: "Forming simple sentences, answering questions, and talking about daily activities.",
  },
  3: {
    topics: "Describing people and places using adjectives",
    example: "My dog is small and cute. = Con chó của tôi nhỏ và dễ thương.",
    activities: "Describing themselves, their friends, and their surroundings.",
  },
  4: {
    topics: "Telling stories and past events",
    example: "Yesterday, I went to the park. = Hôm qua, tôi đã đi đến công viên.",
    activities: "Writing short paragraphs about weekends and favorite activities.",
  },
  5: {
    topics: "Writing opinions and explaining reasons",
    example: "I like pizza because it is delicious. = Tôi thích pizza vì nó rất ngon.",
    activities: "Opinion-based writing and classroom discussions about likes/dislikes.",
  },
  6: {
    topics: "Writing narratives and using descriptive language",
    example: "The water was blue, and the sand was soft. = Nước biển rất xanh và cát rất mềm.",
    activities: "Writing about personal memories or trips.",
  },
  7: {
    topics: "Explaining steps and giving instructions",
    example: "First, take two slices of bread. = Đầu tiên, lấy hai lát bánh mì.",
    activities: "Writing instructions (e.g., how to make a sandwich) and practicing imperatives.",
  },
  8: {
    topics: "Summarizing stories and describing events",
    example: "The story is about a boy who learns to be brave. = Câu chuyện kể về một cậu bé học cách dũng cảm.",
    activities: "Summarizing books or movies and writing about daily events.",
  },
  9: {
    topics: "Writing essays and expressing opinions",
    example: "I want to be a doctor because I like helping people. = Tôi muốn trở thành bác sĩ vì tôi thích giúp đỡ mọi người.",
    activities: "Writing short essays on future goals or ideal schools.",
  },
  10: {
    topics: "Debating and forming arguments",
    example: "I think technology is good because it helps us learn. = Tôi nghĩ công nghệ tốt vì nó giúp chúng ta học hỏi.",
    activities: "Discussing pros and cons of topics like technology and recycling.",
  },
  11: {
    topics: "Analyzing literature and identifying themes",
    example: "The story shows that friendship is important in hard times. = Câu chuyện cho thấy tình bạn quan trọng trong lúc khó khăn.",
    activities: "Writing about themes and characters in stories or poems.",
  },
  12: {
    topics: "Writing research papers and reflections",
    example: "Climate change causes rising sea levels. = Biến đổi khí hậu gây ra mực nước biển dâng cao.",
    activities: "Advanced essays on global issues, reflections on school years, and critical analysis.",
  },
};

export function LearningPlan() {
  const [selectedGrade, setSelectedGrade] = useState<number | null>(null);

  return (
    <div className="space-y-6">
      <h2 className="text-2xl font-bold">English Learning Plan for Vietnamese Students</h2>
      {gradeRanges.map((range, index) => (
        <Card key={index}>
          <CardHeader>
            <CardTitle>{range.name}</CardTitle>
            <CardDescription>{range.description}</CardDescription>
          </CardHeader>
          <CardContent>
            <Accordion type="single" collapsible>
              {range.grades.map((grade) => (
                <AccordionItem key={grade} value={`grade-${grade}`}>
                  <AccordionTrigger>Grade {grade}</AccordionTrigger>
                  <AccordionContent>
                    <div className="space-y-2">
                      <p><strong>Topics:</strong> {gradeContent[grade].topics}</p>
                      <p><strong>Example:</strong> {gradeContent[grade].example}</p>
                      <p><strong>Activities:</strong> {gradeContent[grade].activities}</p>
                      <Button onClick={() => setSelectedGrade(grade)}>Start Learning</Button>
                    </div>
                  </AccordionContent>
                </AccordionItem>
              ))}
            </Accordion>
          </CardContent>
        </Card>
      ))}
      {selectedGrade && (
        <Card>
          <CardHeader>
            <CardTitle>Selected Grade: {selectedGrade}</CardTitle>
          </CardHeader>
          <CardContent>
            <p>Here you can add specific learning content for Grade {selectedGrade}.</p>
          </CardContent>
        </Card>
      )}
    </div>
  );
}

