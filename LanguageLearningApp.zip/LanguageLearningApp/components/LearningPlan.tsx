import React, { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { LearningContent } from './LearningContent'
import { useToast } from "@/components/ui/use-toast"

// ... (keep the existing constants)

export function LearningPlan() {
  // ... (keep the existing state and functions)

  if (selectedLevel) {
    return (
      <LearningContent
        country={countries.find(c => c.code === selectedCountry)?.name || selectedCountry}
        level={selectedLevel}
        content={getContent(selectedCountry, selectedLevel)}
        onBack={() => setSelectedLevel(null)}
        onGenerateNewWords={() => generateNewWords(selectedLevel)}
      />
    );
  }

  return (
    <div className="space-y-6 max-w-4xl mx-auto">
      <h2 className="text-2xl font-bold text-center">Asian Language Learning Plan</h2>
      <div className="flex justify-center">
        <Select onValueChange={(value) => setSelectedCountry(value)}>
          <SelectTrigger className="w-[180px]">
            <SelectValue placeholder="Select a country" />
          </SelectTrigger>
          <SelectContent>
            {countries.map((country) => (
              <SelectItem key={country.code} value={country.code}>
                {country.name}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>
      {educationLevels.map((level, index) => (
        <Card key={index}>
          <CardHeader>
            <CardTitle>{level.name}</CardTitle>
            <CardDescription>English learning content for {level.name}</CardDescription>
          </CardHeader>
          <CardContent>
            <Accordion type="single" collapsible>
              {(level.grades || level.levels).map((grade) => (
                <AccordionItem key={grade} value={`grade-${grade}`}>
                  <AccordionTrigger>{typeof grade === 'number' ? `Grade ${grade}` : grade}</AccordionTrigger>
                  <AccordionContent>
                    <div className="space-y-2">
                      <p><strong>Topics:</strong> {getContent(selectedCountry, grade).topics}</p>
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 p-4 bg-gray-100 rounded-md">
                        <div>
                          <h4 className="font-semibold">Native Language:</h4>
                          <p>{getContent(selectedCountry, grade).example.split('=')[1]?.trim() || 'Translation not available'}</p>
                        </div>
                        <div>
                          <h4 className="font-semibold">English:</h4>
                          <p>{getContent(selectedCountry, grade).example.split('=')[0]?.trim() || 'Example not available'}</p>
                        </div>
                      </div>
                      <p><strong>Activities:</strong> {getContent(selectedCountry, grade).activities}</p>
                      <div className="flex flex-wrap gap-2 justify-center">
                        <Button onClick={() => setSelectedLevel(grade)}>Start Learning</Button>
                        <Button onClick={() => generateNewWords(grade)} variant="outline">Generate New Words</Button>
                      </div>
                    </div>
                  </AccordionContent>
                </AccordionItem>
              ))}
            </Accordion>
          </CardContent>
        </Card>
      ))}
    </div>
  );
}

