import React, { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion"

const gradeRanges = [
  { name: "1st to 3rd Grades", description: "Foundations of English", grades: [1, 2, 3] },
  { name: "4th to 6th Grades", description: "Developing Narratives and Opinions", grades: [4, 5, 6] },
  { name: "7th to 9th Grades", description: "Complex Sentences and Critical Thinking", grades: [7, 8, 9] },
  { name: "10th to 12th Grades", description: "Advanced Writing and Discussions", grades: [10, 11, 12] },
];

const gradeContent = {
  1: {
    topics: "Everyday objects, greetings, simple actions",
    example: "I see a dog = Tôi thấy một con chó.",
    activities: "Tracing letters, copying short sentences, and recognizing objects.",
  },
  2: {
    topics: "Daily routines and basic questions",
    example: "Do you like apples? = Bạn có thích táo không?",
    activities: "Forming simple sentences, answering questions, and talking about daily activities.",
  },
  // ... Add content for grades 3-12 here
};

export function LearningPlan() {
  const [selectedGrade, setSelectedGrade] = useState<number | null>(null);

  return (
    <div className="space-y-6">
      <h2 className="text-2xl font-bold">English Learning Plan for Vietnamese Students</h2>
      {gradeRanges.map((range, index) => (
        <Card key={index}>
          <CardHeader>
            <CardTitle>{range.name}</CardTitle>
            <CardDescription>{range.description}</CardDescription>
          </CardHeader>
          <CardContent>
            <Accordion type="single" collapsible>
              {range.grades.map((grade) => (
                <AccordionItem key={grade} value={`grade-${grade}`}>
                  <AccordionTrigger>Grade {grade}</AccordionTrigger>
                  <AccordionContent>
                    <div className="space-y-2">
                      <p><strong>Topics:</strong> {gradeContent[grade].topics}</p>
                      <p><strong>Example:</strong> {gradeContent[grade].example}</p>
                      <p><strong>Activities:</strong> {gradeContent[grade].activities}</p>
                      <Button onClick={() => setSelectedGrade(grade)}>Start Learning</Button>
                    </div>
                  </AccordionContent>
                </AccordionItem>
              ))}
            </Accordion>
          </CardContent>
        </Card>
      ))}
      {selectedGrade && (
        <Card>
          <CardHeader>
            <CardTitle>Selected Grade: {selectedGrade}</CardTitle>
          </CardHeader>
          <CardContent>
            <p>Here you can add specific learning content for Grade {selectedGrade}.</p>
          </CardContent>
        </Card>
      )}
    </div>
  );
}

