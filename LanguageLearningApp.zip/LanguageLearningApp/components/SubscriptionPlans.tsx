'use client'

import { useState } from 'react';
import { useSession } from 'next-auth/react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { loadStripe } from '@stripe/stripe-js';

const stripePromise = loadStripe(process.env.NEXT_PUBLIC_STRIPE_PUBLISHABLE_KEY!);

const plans = [
  { name: 'Free', price: 0, limit: 10, priceId: 'price_free' },
  { name: 'Intermediate', price: 20, limit: 50, priceId: 'price_intermediate' },
  { name: 'Unlimited', price: 40, limit: Infinity, priceId: 'price_unlimited' },
];

export function SubscriptionPlans() {
  const { data: session } = useSession();
  const [loading, setLoading] = useState(false);

  const handleSubscribe = async (priceId: string) => {
    if (!session?.user?.email) {
      alert('Please log in to subscribe');
      return;
    }

    setLoading(true);
    const response = await fetch('/api/create-checkout-session', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        email: session.user.email,
        priceId,
      }),
    });

    const { sessionId } = await response.json();
    const stripe = await stripePromise;
    const { error } = await stripe!.redirectToCheckout({ sessionId });

    if (error) {
      console.error('Error:', error);
      alert('An error occurred. Please try again.');
    }

    setLoading(false);
  };

  return (
    <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mt-8">
      {plans.map((plan) => (
        <Card key={plan.name}>
          <CardHeader>
            <CardTitle>{plan.name}</CardTitle>
            <CardDescription>
              ${plan.price}/month
            </CardDescription>
          </CardHeader>
          <CardContent>
            <ul className="list-disc list-inside mb-4">
              <li>{plan.limit === Infinity ? 'Unlimited' : plan.limit} messages per day</li>
              {plan.name !== 'Free' && <li>Priority support</li>}
              {plan.name === 'Unlimited' && <li>Advanced features</li>}
            </ul>
            <Button 
              className="w-full" 
              onClick={() => handleSubscribe(plan.priceId)}
              disabled={loading}
            >
              {plan.name === 'Free' ? 'Get Started' : 'Subscribe'}
            </Button>
          </CardContent>
        </Card>
      ))}
    </div>
  );
}

