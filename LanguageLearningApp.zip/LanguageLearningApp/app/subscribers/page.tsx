'use client'

import { useState, useEffect } from 'react';
import { useForm } from 'react-hook-form';
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { SubscriptionPlans } from '@/components/SubscriptionPlans'

interface Subscriber {
  _id: string;
  name: string;
  email: string;
  subscriptionTier: string;
  subscriptionStatus: string;
}

export default function SubscriberManagement() {
  const [subscribers, setSubscribers] = useState<Subscriber[]>([]);
  const { register, handleSubmit, reset } = useForm();

  useEffect(() => {
    fetchSubscribers();
  }, []);

  const fetchSubscribers = async () => {
    const res = await fetch('/api/subscribers');
    const data = await res.json();
    if (data.success) {
      setSubscribers(data.data);
    }
  };

  const onSubmit = async (data) => {
    const res = await fetch('/api/subscribers', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(data),
    });
    const result = await res.json();
    if (result.success) {
      fetchSubscribers();
      reset();
    }
  };

  const handleResetPassword = async (email: string) => {
    const res = await fetch('/api/reset-password', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ email }),
    });
    const result = await res.json();
    if (result.success) {
      alert('Password reset email sent');
    }
  };

  return (
    <div className="container mx-auto px-4 py-8">
      <h1 className="text-4xl font-bold mb-8">Subscriber Management</h1>
      <Card className="mb-8">
        <CardHeader>
          <CardTitle>Add New Subscriber</CardTitle>
          <CardDescription>Enter the details of the new subscriber</CardDescription>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleSubmit(onSubmit)} className="space-y-4">
            <Input {...register('name')} placeholder="Name" required />
            <Input {...register('email')} type="email" placeholder="Email" required />
            <Input {...register('password')} type="password" placeholder="Password" required />
            <Button type="submit">Add Subscriber</Button>
          </form>
        </CardContent>
      </Card>
      <Card className="mb-8">
        <CardHeader>
          <CardTitle>Subscriber List</CardTitle>
          <CardDescription>Manage existing subscribers</CardDescription>
        </CardHeader>
        <CardContent>
          <ul className="space-y-4">
            {subscribers.map((subscriber) => (
              <li key={subscriber._id} className="flex justify-between items-center">
                <div>
                  <p className="font-bold">{subscriber.name}</p>
                  <p>{subscriber.email}</p>
                  <p>Tier: {subscriber.subscriptionTier}</p>
                  <p>Status: {subscriber.subscriptionStatus}</p>
                </div>
                <Button onClick={() => handleResetPassword(subscriber.email)}>Reset Password</Button>
              </li>
            ))}
          </ul>
        </CardContent>
      </Card>
      <Card>
        <CardHeader>
          <CardTitle>Subscription Plans</CardTitle>
          <CardDescription>Choose a subscription plan</CardDescription>
        </CardHeader>
        <CardContent>
          <SubscriptionPlans />
        </CardContent>
      </Card>
    </div>
  );
}

