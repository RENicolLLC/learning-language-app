'use client'

import { useState } from 'react'
import { useParams } from 'next/navigation'
import Link from 'next/link'

export default function LearnLanguage() {
  const params = useParams()
  const lang = params.lang as string

  const [inputText, setInputText] = useState('')
  const [translation, setTranslation] = useState('')

  const handleTranslate = async () => {
    try {
      const response = await fetch('/api/translate', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ text: inputText, targetLang: lang }),
      })
      const data = await response.json()
      setTranslation(data.translation)
    } catch (error) {
      console.error('Translation error:', error)
      setTranslation('Error occurred during translation')
    }
  }

  return (
    <div className="container mx-auto px-4 py-8">
      <h1 className="text-4xl font-bold mb-4">Learn {lang.toUpperCase()}</h1>
      <textarea
        value={inputText}
        onChange={(e) => setInputText(e.target.value)}
        className="w-full p-2 border rounded mb-4"
        rows={4}
        placeholder="Enter text to translate"
      />
      <button
        onClick={handleTranslate}
        className="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded mb-4"
      >
        Translate
      </button>
      {translation && (
        <div className="bg-white p-4 rounded shadow mb-4">
          <h2 className="text-xl font-bold mb-2">Translation:</h2>
          <p>{translation}</p>
        </div>
      )}
      <Link href="/learn" className="text-blue-500 hover:underline">
        Back to language selection
      </Link>
    </div>
  )
}

