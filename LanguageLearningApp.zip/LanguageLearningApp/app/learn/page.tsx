'use client'

import { LearningPlan } from '@/components/LearningPlan'
import { PricingPlans } from '@/components/PricingPlans'

export default function Learn() {
  return (
    <div className="container mx-auto px-4 py-8">
      <h1 className="text-4xl font-bold mb-8">Asian Language Learning</h1>
      <LearningPlan />
      <h2 className="text-3xl font-bold mt-12 mb-6">Pricing Plans</h2>
      <PricingPlans />
    </div>
  )
}

