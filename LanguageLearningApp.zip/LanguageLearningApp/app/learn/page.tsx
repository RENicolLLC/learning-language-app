'use client'

import { useState } from 'react'
import { useSession } from 'next-auth/react'
import { redirect } from 'next/navigation'

export default function Learn() {
  const { data: session, status } = useSession()
  const [input, setInput] = useState('')
  const [response, setResponse] = useState('')

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    const res = await fetch('/api/translate', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ text: input }),
    })
    const data = await res.json()
    setResponse(data.translation)
  }

  if (status === "loading") {
    return <div>Loading...</div>
  }

  if (status === "unauthenticated") {
    redirect("/api/auth/signin")
  }

  return (
    <div className="flex flex-col items-center justify-center min-h-screen py-2">
      <main className="flex flex-col items-center justify-center w-full flex-1 px-20 text-center">
        <h1 className="text-4xl font-bold mb-6">Learn a New Language</h1>
        <form onSubmit={handleSubmit} className="w-full max-w-md">
          <input
            type="text"
            value={input}
            onChange={(e) => setInput(e.target.value)}
            placeholder="Enter text to translate"
            className="w-full px-4 py-2 mb-4 border rounded"
          />
          <button type="submit" className="w-full px-4 py-2 bg-blue-600 text-white rounded">
            Translate
          </button>
        </form>
        {response && (
          <div className="mt-6 p-4 bg-gray-100 rounded">
            <h2 className="text-xl font-bold mb-2">Translation:</h2>
            <p>{response}</p>
          </div>
        )}
      </main>
    </div>
  )
}

