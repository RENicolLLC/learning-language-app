'use client'

import React, { useState } from 'react'
import LevelSelector from '@/components/LevelSelector'
import ContentArea from '@/components/ContentArea'
import CustomInput from '@/components/CustomInput'

const LanguageLearner: React.FC = () => {
  const [level, setLevel] = useState('grade1-3')
  const [contentType, setContentType] = useState('vocabulary')
  const [nativeLanguage, setNativeLanguage] = useState('vietnamese')
  const [customContent, setCustomContent] = useState<null | {
    native: string;
    english: string;
    activity: string;
  }>(null)
  const [isLoading, setIsLoading] = useState(false)

  const handleCustomInput = async (input: string) => {
    setIsLoading(true)
    try {
      const response = await fetch('/api/translate', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          text: input,
          fromLanguage: nativeLanguage,
          toLanguage: 'english',
        }),
      })

      if (!response.ok) {
        throw new Error('Translation failed')
      }

      const data = await response.json()
      setCustomContent({
        native: input,
        english: data.translation,
        activity: data.activity,
      })
    } catch (error) {
      console.error('Error:', error)
      setCustomContent({
        native: input,
        english: 'Translation failed',
        activity: 'Unable to generate activity',
      })
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <div className="w-full max-w-4xl mx-auto p-4">
      <LevelSelector level={level} setLevel={setLevel} />
      <div className="mb-4">
        <label htmlFor="nativeLanguage" className="block text-sm font-medium text-gray-700">
          Native Language
        </label>
        <select 
          id="nativeLanguage"
          value={nativeLanguage} 
          onChange={(e) => setNativeLanguage(e.target.value)}
          className="mt-1 block w-full pl-3 pr-10 py-2 text-base border-gray-300 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm rounded-md"
        >
          <option value="english">English</option>
          <option value="vietnamese">Vietnamese</option>
          <option value="chinese">Chinese</option>
          <option value="japanese">Japanese</option>
          <option value="korean">Korean</option>
          <option value="thai">Thai</option>
        </select>
      </div>
      <div className="mb-4">
        <label htmlFor="contentType" className="block text-sm font-medium text-gray-700">
          Content Type
        </label>
        <select 
          id="contentType"
          value={contentType} 
          onChange={(e) => setContentType(e.target.value)}
          className="mt-1 block w-full pl-3 pr-10 py-2 text-base border-gray-300 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm rounded-md"
        >
          <option value="vocabulary">Vocabulary</option>
          <option value="grammar">Grammar</option>
          <option value="conversation">Conversation</option>
        </select>
      </div>
      <ContentArea level={level} contentType={contentType} nativeLanguage={nativeLanguage} />
      <CustomInput onSubmit={handleCustomInput} nativeLanguage={nativeLanguage} isLoading={isLoading} />
      {customContent && (
        <ContentArea
          level={level}
          contentType="custom"
          nativeLanguage={nativeLanguage}
          customContent={customContent}
        />
      )}
    </div>
  )
}

export default LanguageLearner

