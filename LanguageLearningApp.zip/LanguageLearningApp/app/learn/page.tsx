import Link from 'next/link'

export default function Learn() {
  return (
    <div className="container mx-auto px-4 py-8">
      <h1 className="text-4xl font-bold mb-4">Learn a New Language</h1>
      <p className="mb-4">Choose a language to start learning:</p>
      <ul className="list-disc list-inside mb-4">
        <li>Spanish</li>
        <li>French</li>
        <li>German</li>
        <li>Italian</li>
      </ul>
      <Link href="/" className="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded">
        Back to Home
      </Link>
    </div>
  )
}

