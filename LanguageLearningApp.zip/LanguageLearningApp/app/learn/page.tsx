'use client'

import { useState } from 'react'
import Link from 'next/link'

export default function Learn() {
  const [selectedLanguage, setSelectedLanguage] = useState('')

  const languages = [
    { code: 'vi', name: 'Vietnamese' },
    { code: 'zh', name: 'Chinese' },
    { code: 'ja', name: 'Japanese' },
    { code: 'ko', name: 'Korean' },
    { code: 'th', name: 'Thai' },
  ]

  return (
    <div className="container mx-auto px-4 py-8">
      <h1 className="text-4xl font-bold mb-4">Learn a New Language</h1>
      <p className="mb-4">Choose a language to start learning:</p>
      <select 
        value={selectedLanguage} 
        onChange={(e) => setSelectedLanguage(e.target.value)}
        className="mb-4 p-2 border rounded"
      >
        <option value="">Select a language</option>
        {languages.map((lang) => (
          <option key={lang.code} value={lang.code}>{lang.name}</option>
        ))}
      </select>
      {selectedLanguage && (
        <p className="mb-4">You selected: {languages.find(lang => lang.code === selectedLanguage)?.name}</p>
      )}
      <Link href="/" className="text-blue-500 hover:underline">
        Back to Home
      </Link>
    </div>
  )
}

