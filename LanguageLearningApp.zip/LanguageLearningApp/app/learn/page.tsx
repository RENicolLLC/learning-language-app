export default function Learn() {
  return (
    <div className="flex flex-col items-center justify-center min-h-screen py-2">
      <h1 className="text-4xl font-bold mb-6">Learn a New Language</h1>
      <p>This is the learning page. Content will be added soon.</p>
    </div>
  )
}

