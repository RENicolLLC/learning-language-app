import { NextResponse } from 'next/server';
import stripe from '@/lib/stripe';
import dbConnect from '@/lib/dbConnect';
import Subscriber from '@/models/Subscriber';

const DOMAIN = process.env.NEXT_PUBLIC_URL;

export async function POST(req: Request) {
  try {
    await dbConnect();
    const { email, priceId } = await req.json();

    // Find the subscriber
    const subscriber = await Subscriber.findOne({ email });
    if (!subscriber) {
      return NextResponse.json({ error: 'Subscriber not found' }, { status: 404 });
    }

    // Create or retrieve the Stripe customer
    let customerId = subscriber.stripeCustomerId;
    if (!customerId) {
      const customer = await stripe.customers.create({ email });
      customerId = customer.id;
      subscriber.stripeCustomerId = customerId;
      await subscriber.save();
    }

    // Create the checkout session
    const session = await stripe.checkout.sessions.create({
      customer: customerId,
      line_items: [
        {
          price: priceId,
          quantity: 1,
        },
      ],
      mode: 'subscription',
      success_url: `${DOMAIN}/subscription-success?session_id={CHECKOUT_SESSION_ID}`,
      cancel_url: `${DOMAIN}/subscription-cancelled`,
    });

    return NextResponse.json({ sessionId: session.id });
  } catch (error) {
    console.error('Error creating checkout session:', error);
    return NextResponse.json({ error: 'Error creating checkout session' }, { status: 500 });
  }
}

