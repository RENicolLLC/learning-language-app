import { NextResponse } from 'next/server';
import { headers } from 'next/headers';
import stripe from '@/lib/stripe';
import dbConnect from '@/lib/dbConnect';
import Subscriber from '@/models/Subscriber';

export async function POST(req: Request) {
  const body = await req.text();
  const sig = headers().get('stripe-signature') as string;

  let event;

  try {
    event = stripe.webhooks.constructEvent(body, sig, process.env.STRIPE_WEBHOOK_SECRET!);
  } catch (err: any) {
    return NextResponse.json({ error: `Webhook Error: ${err.message}` }, { status: 400 });
  }

  await dbConnect();

  switch (event.type) {
    case 'customer.subscription.created':
    case 'customer.subscription.updated':
      const subscription = event.data.object as Stripe.Subscription;
      const subscriber = await Subscriber.findOne({ stripeCustomerId: subscription.customer as string });
      if (subscriber) {
        subscriber.subscriptionStatus = subscription.status === 'active' ? 'active' : 'inactive';
        subscriber.subscriptionTier = subscription.items.data[0].price.lookup_key as 'free' | 'intermediate' | 'unlimited';
        subscriber.subscriptionEndDate = new Date(subscription.current_period_end * 1000);
        await subscriber.save();
      }
      break;
    case 'customer.subscription.deleted':
      const deletedSubscription = event.data.object as Stripe.Subscription;
      const subscriberToUpdate = await Subscriber.findOne({ stripeCustomerId: deletedSubscription.customer as string });
      if (subscriberToUpdate) {
        subscriberToUpdate.subscriptionStatus = 'cancelled';
        subscriberToUpdate.subscriptionTier = 'free';
        subscriberToUpdate.subscriptionEndDate = new Date();
        await subscriberToUpdate.save();
      }
      break;
  }

  return NextResponse.json({ received: true });
}

