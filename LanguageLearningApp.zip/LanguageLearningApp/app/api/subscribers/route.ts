import { NextResponse } from 'next/server';
import dbConnect from '@/lib/dbConnect';
import Subscriber from '@/models/Subscriber';
import bcrypt from 'bcryptjs';

export async function POST(req: Request) {
  try {
    await dbConnect();
    const { name, email, phoneNumber, password } = await req.json();

    const hashedPassword = await bcrypt.hash(password, 10);

    const subscriber = await Subscriber.create({
      name,
      email,
      phoneNumber,
      password: hashedPassword,
    });

    return NextResponse.json({ success: true, data: subscriber }, { status: 201 });
  } catch (error) {
    return NextResponse.json({ success: false, error: 'Error creating subscriber' }, { status: 400 });
  }
}

export async function GET() {
  try {
    await dbConnect();
    const subscribers = await Subscriber.find({}).select('-password');
    return NextResponse.json({ success: true, data: subscribers });
  } catch (error) {
    return NextResponse.json({ success: false, error: 'Error fetching subscribers' }, { status: 400 });
  }
}

