import { NextResponse } from 'next/server'
import OpenAI from 'openai'

const openai = new OpenAI({
  apiKey: process.env.OPENAI_API_KEY,
})

export async function POST(req: Request) {
  const { text, targetLang } = await req.json()

  try {
    const completion = await openai.chat.completions.create({
      model: "gpt-3.5-turbo",
      messages: [
        { role: "system", content: `You are a helpful assistant that translates English to ${targetLang}.` },
        { role: "user", content: `Translate the following English text to ${targetLang}: "${text}"` }
      ],
    })

    const translation = completion.choices[0].message.content

    return NextResponse.json({ translation })
  } catch (error) {
    console.error('OpenAI API error:', error)
    return NextResponse.json({ error: 'Translation failed' }, { status: 500 })
  }
}

