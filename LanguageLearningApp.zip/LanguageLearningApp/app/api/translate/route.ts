import { NextResponse } from 'next/server'
import OpenAI from 'openai'

const openai = new OpenAI({
  apiKey: process.env.OPENAI_API_KEY,
})

export async function POST(req: Request) {
  const { text, fromLanguage, toLanguage } = await req.json()

  try {
    const completion = await openai.chat.completions.create({
      model: "gpt-3.5-turbo",
      messages: [
        {
          role: "system",
          content: `You are a helpful assistant that translates ${fromLanguage} to ${toLanguage} and provides language learning activities.`
        },
        {
          role: "user",
          content: `Translate the following ${fromLanguage} text to ${toLanguage} and suggest a language learning activity: "${text}"`
        }
      ],
    })

    const result = completion.choices[0].message.content
    const [translation, activity] = result.split('\n\n')

    return NextResponse.json({ translation, activity })
  } catch (error) {
    console.error('OpenAI API error:', error)
    return NextResponse.json({ error: 'Translation failed' }, {
status: 500
    })
  }
}

